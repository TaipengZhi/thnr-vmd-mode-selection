function run_confirmation_bcde()
% CONFIRMATION EXPERIMENT (Plan-4, frozen protocol v1).
% Independent confirmation set with seeds fully disjoint from all prior runs.
% One shared VMD per signal; compute B, C, D, E, oracle + all 15 subsets.
% B = SES-Gini top-1 bandpass (no VMD)
% C = all 4 modes summed (code 15)
% D = single mode with max THNR (codes 1,2,4,8)
% E = exhaustive 15-subset THNR max (production final method)
% oracle = subset maximising output SNR (diagnostic only)
root='D:\two_stage_vmd_fggi_project\sci\matlab_experiments';
fz='D:\two_stage_vmd_fggi_project\frozen_v21';
addpath(fz); addpath(fullfile(root,'user_methods')); addpath(root);

opts=fz_defaults();
fs=25600; dur=1.0; rot=30; ff=107.36; resHz=4500;
% ---- Load frozen parameters to match production method exactly ----
fpStruct = load(fullfile(root,'frozen_parameters.mat'));
fp = fpStruct.frozen_parameters;
opts.harmonic_order = fp.H;
opts.delta_ff_coef = fp.df_tol_hz / ff;  % ensures delta = max(3*df, df_tol_hz)
fprintf('Frozen params loaded: H=%d, df_tol_hz=%.3f -> delta_ff_coef=%.6f\n', fp.H, fp.df_tol_hz, opts.delta_ff_coef);
fprintf('  Expected delta = max(%.4f, %.4f) = %.4f Hz\n', 3*fs/2^nextpow2(fs*dur), opts.delta_ff_coef*ff, max(3*fs/2^nextpow2(fs*dur), opts.delta_ff_coef*ff));
resBand=[3500 5500]; damp=0.035; jit=0.01;
snrList=[-15 -10 -5 0 5];
noiseList=["white","pink","impulsive","harmonic"];
nR=50;
% ---- NEW SEED BASE, fully disjoint from prior 20260929 range ----
random_seed=30261008;

p=gcp('nocreate'); if isempty(p), parpool('local',4); end

nCell=20;
outSum=cell(1,nCell); tag=cell(1,nCell);
parfor idx=1:nCell
  ni=ceil(idx/5); si=idx-(ni-1)*5;
  nt=noiseList(ni); snrDb=snrList(si);
  rowsS=strings(0,1);
  for r=1:nR
    seed=random_seed+100000+r+1000*si+10000*ni;
    [clean,noisy]=make_case(fs,dur,rot,ff,resHz,resBand,damp,jit,nt,snrDb,seed);
    x=noisy(:).'; N=numel(x);
    t0=tic;
    [cand,~]=fz_gini_recall(x,fs,opts);
    X=fft(x-mean(x),N);
    xn=fz_bandpass_mask(X,N,cand(1,3),cand(1,4),fs);
    bw=cand(1,2); alpha0=opts.alpha_scale*fs/bw; Kfix=4;
    [u,~,~,~]=fz_vmd(xn,alpha0,opts.vmd_tau,Kfix,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,opts.vmd_max_iter);
    imfs=u.';
    res=fz_mode_subset_select(imfs,fs,ff,opts);
    eMask=false(1,Kfix); eMask(res.keep)=true; eCode=mask_code(eMask);
    allEnergy=sum(sum(imfs,1).^2);
    thnrV=nan(1,15); snrV=nan(1,15); rrmseV=nan(1,15); corrV=nan(1,15); erV=nan(1,15); nV=zeros(1,15);
    ref=fft_bp(clean,fs,resBand);
    for code=1:15
      m=code_mask(code,Kfix); nV(code)=nnz(m);
      recon=sum(imfs(m,:),1);
      [A,fq]=fz_amp_env_spectrum(recon,fs);
      R=fz_thnr(A,fq,ff,opts); thnrV(code)=R.thnr;
      est=fft_bp(recon(:),fs,resBand); err=ref-est;
      snrV(code)=10*log10(sum(ref.^2)/max(sum(err.^2),eps));
      rrmseV(code)=sqrt(mean(err.^2))/max(sqrt(mean(ref.^2)),eps);
      cc=corrcoef(ref,est); corrV(code)=cc(1,2);
      erV(code)=sum(recon.^2)/max(allEnergy,eps);
    end
    % B: bandpass output (no VMD)
    estB=fft_bp(xn(:),fs,resBand); errB=ref-estB;
    bSnr=10*log10(sum(ref.^2)/max(sum(errB.^2),eps));
    bRrmse=sqrt(mean(errB.^2))/max(sqrt(mean(ref.^2)),eps);
    ccB=corrcoef(ref,estB); bCorr=ccB(1,2);
    % C: all modes (code 15)
    cSnr=snrV(15); cRrmse=rrmseV(15); cCorr=corrV(15); cThnr=thnrV(15);
    % D: single mode with max THNR
    singleCodes=[1 2 4 8]; [~,dIdx]=max(thnrV(singleCodes));
    dCode=singleCodes(dIdx);
    dSnr=snrV(dCode); dRrmse=rrmseV(dCode); dCorr=corrV(dCode); dThnr=thnrV(dCode);
    % E
    eSnr=snrV(eCode); eRrmse=rrmseV(eCode); eCorr=corrV(eCode); eThnr=thnrV(eCode);
    % oracle
    [oracleSnr,oCode]=max(snrV);
    regret=oracleSnr-eSnr;
    srtV=sort(snrV,'descend'); eInTop3=eSnr>=srtV(3)-1e-9;
    okFin=isfinite(thnrV)&isfinite(snrV);
    if nnz(okFin)>2, sp=corr(thnrV(okFin).',snrV(okFin).','type','Spearman'); else sp=NaN; end
    oracleAll=double(oCode==15);
    el=toc(t0);
    rowsS(end+1)=sprintf('%s,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%d,%d,%d,%d,%d,%d,%.6f,%.6f,%.3f,%.3f,%.4f', ...
      char(nt),snrDb,r, ...
      bSnr,cSnr,dSnr,eSnr,oracleSnr, ...
      bRrmse,cRrmse,dRrmse,eRrmse, ...
      bCorr,cCorr,dCorr,eCorr, ...
      eThnr,dThnr,cThnr, ...
      eCode,dCode,oCode,nV(eCode),nV(dCode), ...
      regret,double(eCode==oCode),double(eInTop3),sp,oracleAll,alpha0,bw,el); %#ok<AGROW>
  end
  outSum{idx}=rowsS; tag{idx}=sprintf('%s_%d',char(nt),snrDb);
end

outDir='C:\Users\Zhi\Doubao\chats\2026-09-21\new-chat';
fS=fopen(fullfile(outDir,'confirmation_bcde_oracle.csv'),'w');
fprintf(fS,'noise_type,input_snr_db,repetition,b_snr,c_snr,d_snr,e_snr,oracle_snr,b_rrmse,c_rrmse,d_rrmse,e_rrmse,b_corr,c_corr,d_corr,e_corr,e_thnr_db,d_thnr_db,c_thnr_db,e_mask,d_mask,oracle_mask,e_nmask,d_nmask,regret_db,e_eq_oracle,e_in_top3,spearman_thnr_snr,oracle_all_modes,alpha0,bw,runtime_s\n');
for idx=1:nCell
  fprintf(fS,'%s\n',outSum{idx});
end
fclose(fS);
fprintf('CONFIRMATION ALL DONE: 1000 signals\n');
end

function c=mask_code(m), c=0; for b=1:numel(m), if m(b), c=c+2^(b-1); end, end, end
function m=code_mask(code,K), m=false(1,K); tmp=code; for b=1:K, m(b)=bitand(tmp,1)==1; tmp=bitshift(tmp,-1); end, end

function [clean,noisy]=make_case(fs,dur,rot,ff,resHz,resBand,damp,jit,nt,snrDb,seed)
rng(seed,'twister');
n=round(dur*fs); t=(0:n-1)'/fs;
period=1/ff;
impactTimes=(0:period:dur)';
impactTimes=impactTimes+jit*period*randn(size(impactTimes));
impactTimes=impactTimes(impactTimes>=0&impactTimes<dur);
impulses=zeros(n,1);
idx=min(n,max(1,round(impactTimes*fs)+1));
impulses(idx)=1+0.15*randn(size(idx));
ringLength=min(n,round(0.05*fs));
tr=(0:ringLength-1)'/fs;
ring=exp(-2*pi*damp*resHz*tr).*sin(2*pi*resHz*tr);
faultComponent=conv(impulses,ring,'full'); faultComponent=faultComponent(1:n);
background=0.08*sin(2*pi*rot*t)+0.04*sin(2*pi*2*rot*t+0.4);
clean=faultComponent+background;
noise=make_noise(nt,n,fs,ff);
signalPower=mean(faultComponent.^2); noisePower=mean(noise.^2);
scale=sqrt(signalPower/max(noisePower,eps)/10^(snrDb/10));
noisy=clean+scale*noise;
end

function noise=make_noise(nt,n,fs,ff)
t=(0:n-1)'/fs;
switch string(nt)
  case "white", noise=randn(n,1);
  case "pink"
    spectrum=zeros(n,1); nPos=n/2-1; w=1./sqrt((1:nPos).');
    halfSpec=w.*exp(1i*2*pi*rand(nPos,1));
    spectrum(1)=0; spectrum(2:nPos+1)=halfSpec;
    spectrum(n/2+1)=0; spectrum(n/2+2:n)=conj(flipud(halfSpec));
    noise=real(ifft(spectrum));
  case "impulsive"
    noise=0.2*randn(n,1); count=max(3,round(n/fs*12));
    ii=randperm(n,min(count,n)); noise(ii)=noise(ii)+8*randn(numel(ii),1);
  case "harmonic"
    noise=randn(n,1)*0.15+sin(2*pi*0.95*ff*t)+0.7*sin(2*pi*1.05*ff*t+0.7);
end
noise=noise-mean(noise); noise=noise/max(std(noise),eps);
end

function y=fft_bp(x,fs,band)
n=numel(x); X=fft(x); f=(0:n-1)'*fs/n;
mask=(f>=band(1)&f<=band(2))|(f>=fs-band(2)&f<=fs-band(1));
y=real(ifft(X.*mask)); y=y-mean(y);
end
