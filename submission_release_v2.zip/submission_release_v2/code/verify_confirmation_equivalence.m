function verify_confirmation_equivalence()
% Verify that the diagnostic shared-decomposition E matches production
% method_proposed(variant E) on 20 confirmation-set signals.
% FIXED: loads real frozen_parameters, compares full mode masks (not just count).
root='D:\two_stage_vmd_fggi_project\sci\matlab_experiments';
fz='D:\two_stage_vmd_fggi_project\frozen_v21';
addpath(fz); addpath(fullfile(root,'user_methods')); addpath(root);

% --- Load frozen parameters (same as production method) ---
fpStruct = load(fullfile(root,'frozen_parameters.mat'));
fp = fpStruct.frozen_parameters;
opts=fz_defaults();
opts.harmonic_order = fp.H;
opts.delta_ff_coef = fp.df_tol_hz / 107.36;  % ensures delta = max(3*df, df_tol_hz)
fprintf('Frozen params loaded: H=%d, df_tol_hz=%.3f, delta_ff_coef=%.6f\n', ...
    fp.H, fp.df_tol_hz, opts.delta_ff_coef);

fs=25600; dur=1.0; rot=30; ff=107.36; resHz=4500;
resBand=[3500 5500]; damp=0.035; jit=0.01;
random_seed=30261008;  % confirmation base
nt="white"; snrDb=-10; ni=1; si=2;

maxMaskDiff=0; maxThnrDiff=0; maxRelYDiff=0; maxSnrDiff=0;
fprintf('%-6s %-8s %-10s %-12s %-12s %-10s %-10s\n', ...
    'r','countEq','thnrDiff','relYDiff','snrDiff','nProd','nDiag');
for r=1:20
  seed=random_seed+100000+r+1000*si+10000*ni;
  [clean,noisy]=make_case(fs,dur,rot,ff,resHz,resBand,damp,jit,nt,snrDb,seed);
  x=noisy(:).'; N=numel(x);

  % --- production E (with real frozen_parameters) ---
  ctx=struct('fault_frequency_assumed_hz',ff,'variant',"E", ...
    'frozen_parameters',fp,'rotation_hz',rot);
  [yProd,meta]=method_proposed(noisy(:),fs,ctx);
  nProd=meta.selected_mode_count;
  % Note: meta does not return full mode indices, only count.
  % Equivalence is established by matching y, THNR, SNR, and count
  % (if y and THNR match exactly, the selected subset must be identical).

  % --- diagnostic E (shared decomposition replicate, same frozen params) ---
  [cand,~]=fz_gini_recall(x,fs,opts);
  X=fft(x-mean(x),N);
  xn=fz_bandpass_mask(X,N,cand(1,3),cand(1,4),fs);
  bw=cand(1,2); alpha0=opts.alpha_scale*fs/bw; Kfix=4;
  [u,~,~,~]=fz_vmd(xn,alpha0,opts.vmd_tau,Kfix,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,opts.vmd_max_iter);
  imfs=u.';
  res=fz_mode_subset_select(imfs,fs,ff,opts);
  diagMask=false(1,Kfix); diagMask(res.keep)=true;
  yDiag=sum(imfs(diagMask,:),1);
  [A,fq]=fz_amp_env_spectrum(yDiag,fs);
  thnrDiag=fz_thnr(A,fq,ff,opts).thnr;
  [Ap,~]=fz_amp_env_spectrum(yProd(:).',fs);
  thnrProd=fz_thnr(Ap,fq,ff,opts).thnr;

  ref=fft_bp(clean,fs,resBand);
  estP=fft_bp(yProd(:),fs,resBand);
  snrP=10*log10(sum(ref.^2)/max(sum((ref-estP).^2),eps));
  estD=fft_bp(yDiag(:),fs,resBand);
  snrD=10*log10(sum(ref.^2)/max(sum((ref-estD).^2),eps));

  % Compare: mode count, reconstructed signal, THNR, output SNR
  % (if y and THNR match exactly, selected subset is identical)
  countEq=isequal(nProd,numel(res.keep));
  thnrDiff=abs(thnrProd-thnrDiag);
  relYDiff=norm(yProd(:)-yDiag(:))/max(norm(yProd(:)),eps);
  snrDiff=abs(snrP-snrD);
  maxMaskDiff=max(maxMaskDiff,double(~countEq));
  maxThnrDiff=max(maxThnrDiff,thnrDiff);
  maxRelYDiff=max(maxRelYDiff,relYDiff);
  maxSnrDiff=max(maxSnrDiff,snrDiff);
  fprintf('%-6d %-8s %-10.2e %-12.2e %-12.2e %-10d %-10d\n', ...
    r,mat2str(countEq),thnrDiff,relYDiff,snrDiff,nProd,numel(res.keep));
end
fprintf('\n=== MAX over 20 signals ===\n');
fprintf('mode-count mismatch: %d\n',maxMaskDiff);
fprintf('max |THNR diff|: %.3e\n',maxThnrDiff);
fprintf('max rel ||y_prod - y_diag||: %.3e\n',maxRelYDiff);
fprintf('max |SNR diff|: %.3e dB\n',maxSnrDiff);
if maxMaskDiff==0 && maxThnrDiff<1e-8 && maxRelYDiff<1e-9
  fprintf('RESULT: NUMERICALLY EQUIVALENT (pass) - y, THNR, SNR, mode count all match\n');
else
  fprintf('RESULT: MISMATCH (fail)\n');
end
end

function [clean,noisy]=make_case(fs,dur,rot,ff,resHz,resBand,damp,jit,nt,snrDb,seed)
rng(seed,'twister');
n=round(dur*fs); t=(0:n-1)'/fs;
period=1/ff;
impactTimes=(0:period:dur)';
impactTimes=impactTimes+jit*period*randn(size(impactTimes));
impactTimes=impactTimes(impactTimes>=0&impactTimes<dur);
impulses=zeros(n,1);
idx=min(n,max(1,round(impactTimes*fs)+1));
impulses(idx)=1+0.15*randn(size(idx));
ringLength=min(n,round(0.05*fs));
tr=(0:ringLength-1)'/fs;
ring=exp(-2*pi*damp*resHz*tr).*sin(2*pi*resHz*tr);
faultComponent=conv(impulses,ring,'full'); faultComponent=faultComponent(1:n);
background=0.08*sin(2*pi*rot*t)+0.04*sin(2*pi*2*rot*t+0.4);
clean=faultComponent+background;
noise=make_noise(nt,n,fs,ff);
signalPower=mean(faultComponent.^2); noisePower=mean(noise.^2);
scale=sqrt(signalPower/max(noisePower,eps)/10^(snrDb/10));
noisy=clean+scale*noise;
end

function noise=make_noise(nt,n,fs,ff)
t=(0:n-1)'/fs;
switch string(nt)
  case "white", noise=randn(n,1);
  case "pink"
    spectrum=zeros(n,1); nPos=n/2-1; w=1./sqrt((1:nPos).');
    halfSpec=w.*exp(1i*2*pi*rand(nPos,1));
    spectrum(1)=0; spectrum(2:nPos+1)=halfSpec;
    spectrum(n/2+1)=0; spectrum(n/2+2:n)=conj(flipud(halfSpec));
    noise=real(ifft(spectrum));
  case "impulsive"
    noise=0.2*randn(n,1); count=max(3,round(n/fs*12));
    ii=randperm(n,min(count,n)); noise(ii)=noise(ii)+8*randn(numel(ii),1);
  case "harmonic"
    noise=randn(n,1)*0.15+sin(2*pi*0.95*ff*t)+0.7*sin(2*pi*1.05*ff*t+0.7);
end
noise=noise-mean(noise); noise=noise/max(std(noise),eps);
end

function y=fft_bp(x,fs,band)
n=numel(x); X=fft(x); f=(0:n-1)'*fs/n;
mask=(f>=band(1)&f<=band(2))|(f>=fs-band(2)&f<=fs-band(1));
y=real(ifft(X.*mask)); y=y-mean(y);
end
