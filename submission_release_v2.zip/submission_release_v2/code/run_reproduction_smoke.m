function run_reproduction_smoke()
%RUN_REPRODUCTION_SMOKE  Verify the release package runs in a clean MATLAB session.
%
%   This script verifies that the THNR-guided VMD mode-subset selection
%   method (variant E) can be reproduced from the release package alone,
%   without access to the original D:\two_stage_vmd_fggi_project tree.
%
%   It performs three checks:
%     1. Path setup: adds code/ and code/frozen_v21/ to MATLAB path.
%     2. Core function availability: verifies all required functions exist.
%     3. End-to-end smoke test: runs variant E on a short synthetic signal
%        and checks that the output structure contains expected fields.
%
%   Usage:
%     >> cd <release_root>
%     >> run_reproduction_smoke
%
%   Expected output: all checks PASS.
%
%   Requirements:
%     - MATLAB R2021a or later (tested on R2025a)
%     - Signal Processing Toolbox (for fft, hilbert, filter)
%     - No other toolboxes required
%
%   See also method_proposed, fz_defaults, fz_gini_recall, fz_vmd,
%            fz_mode_subset_select, fz_thnr.

    fprintf('========================================\n');
    fprintf('  Reproduction Smoke Test\n');
    fprintf('========================================\n\n');

    % --- Determine release root ---
    thisFile = mfilename('fullpath');
    releaseRoot = fileparts(thisFile);
    fprintf('Release root: %s\n\n', releaseRoot);

    % --- Check 1: Path setup ---
    fprintf('[CHECK 1] Path setup\n');
    codeDir = fullfile(releaseRoot, 'code');
    frozenDir = fullfile(releaseRoot, 'code', 'frozen_v21');
    userMethodsDir = fullfile(releaseRoot, 'code', 'user_methods');

    assert(exist(codeDir, 'dir') == 7, 'code/ directory not found at %s', codeDir);
    assert(exist(frozenDir, 'dir') == 7, 'code/frozen_v21/ directory not found at %s', frozenDir);
    assert(exist(userMethodsDir, 'dir') == 7, 'code/user_methods/ directory not found at %s', userMethodsDir);

    addpath(codeDir);
    addpath(frozenDir);
    addpath(userMethodsDir);
    fprintf('  Added to path: code/\n');
    fprintf('  Added to path: code/frozen_v21/\n');
    fprintf('  Added to path: code/user_methods/\n');
    fprintf('  PASS\n\n');

    % --- Check 2: Core function availability ---
    fprintf('[CHECK 2] Core function availability\n');
    requiredFunctions = {
        'method_proposed'
        'fz_defaults'
        'fz_gini_recall'
        'fz_bandpass_mask'
        'fz_vmd'
        'fz_mode_subset_select'
        'fz_thnr'
        'fz_amp_env_spectrum'
        'fz_ses_gini'
        'fz_sim_signal'
        'fz_kinematic_ff'
        'fz_norm_env_half'
        'locate_frozen_dir'
    };

    allFound = true;
    for i = 1:numel(requiredFunctions)
        fn = requiredFunctions{i};
        if exist(fn, 'file') == 2 || exist(fn, 'file') == 6
            fprintf('  OK: %s\n', fn);
        else
            fprintf('  MISSING: %s\n', fn);
            allFound = false;
        end
    end
    assert(allFound, 'One or more required functions are missing.');
    fprintf('  PASS\n\n');

    % --- Check 3: End-to-end smoke test ---
    fprintf('[CHECK 3] End-to-end smoke test (variant E)\n');

    % Generate a short synthetic bearing fault signal
    fs = 25600;
    duration = 1.0;  % 1 second
    t = (0:1/fs:duration-1/fs)';
    N = numel(t);

    % Simulate a bearing outer-race fault with resonance
    fr = 30;  % rotational frequency Hz
    BPFO = 3.5 * fr;  % ~105 Hz
    resonance = 3000;  % Hz
    damping = 0.05;

    % Impulse train
    impulses = zeros(N, 1);
    period_samples = round(fs / BPFO);
    for k = 1:round(duration * BPFO)
        idx = (k-1) * period_samples + 1;
        if idx <= N
            impulses(idx) = 1;
        end
    end

    % Convolve with damped oscillation
    impulse_response = exp(-damping * 2 * pi * resonance * t) .* sin(2 * pi * resonance * t);
    fault_signal = conv(impulses, impulse_response);
    fault_signal = fault_signal(1:N);

    % Add white noise at -10 dB SNR
    signalPower = mean(fault_signal.^2);
    noisePower = signalPower / 10^(10/10);  % -10 dB
    rng(42, 'twister');  % fixed seed for reproducibility
    noise = sqrt(noisePower) * randn(N, 1);
    x = fault_signal + noise;

    fprintf('  Signal: %d samples, fs=%d Hz, BPFO=%.1f Hz, SNR=-10 dB\n', N, fs, BPFO);

    % Load frozen parameters
    fp_path = fullfile(codeDir, 'frozen_parameters.mat');
    assert(exist(fp_path, 'file') == 2, 'frozen_parameters.mat not found at %s', fp_path);
    fp = load(fp_path);
    fprintf('  Loaded frozen_parameters.mat (K=%d, H=%d)\n', fp.K_list(1), fp.H);

    % Build options
    opts = fz_defaults();
    opts.variant = 'E';
    opts.K = 4;
    opts.H = fp.H;
    opts.df_tol_hz = fp.df_tol_hz;
    opts.alpha_scale = 200;

    % Run method
    fprintf('  Running method_proposed (variant E)...\n');
    result = method_proposed(x, fs, BPFO, opts);

    % Verify output structure
    assert(isfield(result, 'y'), 'Output missing reconstructed signal y');
    assert(isfield(result, 'meta'), 'Output missing meta structure');
    assert(numel(result.y) == N, 'Output length mismatch: expected %d, got %d', N, numel(result.y));
    assert(~all(isnan(result.y)), 'Output contains all NaN');

    fprintf('  Output signal length: %d samples\n', numel(result.y));
    fprintf('  Output RMS: %.4f\n', rms(result.y));

    if isfield(result.meta, 'selected_mode_count')
        fprintf('  Selected mode count: %d\n', result.meta.selected_mode_count);
    end
    if isfield(result.meta, 'selected_thnr_db')
        fprintf('  Selected THNR: %.2f dB\n', result.meta.selected_thnr_db);
    end

    fprintf('  PASS\n\n');

    % --- Summary ---
    fprintf('========================================\n');
    fprintf('  ALL CHECKS PASSED\n');
    fprintf('  Release package is self-contained.\n');
    fprintf('========================================\n');
end
