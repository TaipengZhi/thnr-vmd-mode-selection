function run_oracle_diagnosis()
% Oracle subset diagnosis (Plan-4, Stage 2). For every S1 signal (same seeds
% as production), replicate variant E to the K=4 VMD modes, then evaluate ALL
% 15 non-empty subsets on THNR (internal objective) and output SNR / RRMSE /
% corr (clean reference) and subset energy ratio. Compare THNR-selected (E)
% vs oracle (max output SNR) vs all-mode subset. Diagnostic only.
root='D:\two_stage_vmd_fggi_project\sci\matlab_experiments';
fz='D:\two_stage_vmd_fggi_project\frozen_v21';
addpath(fz); addpath(fullfile(root,'user_methods')); addpath(root);

opts=fz_defaults();
fs=25600; dur=1.0; rot=30; ff=107.36; resHz=4500;
% ---- Load frozen parameters to match production method exactly ----
fpStruct = load(fullfile(root,'frozen_parameters.mat'));
fp = fpStruct.frozen_parameters;
opts.harmonic_order = fp.H;
opts.delta_ff_coef = fp.df_tol_hz / ff;  % ensures delta = max(3*df, df_tol_hz)
fprintf('Frozen params loaded: H=%d, df_tol_hz=%.3f -> delta=%.4f Hz\n', fp.H, fp.df_tol_hz, max(3*fs/2^nextpow2(fs*dur), fp.df_tol_hz));
resBand=[3500 5500]; damp=0.035; jit=0.01;
snrList=[-15 -10 -5 0 5];
noiseList=["white","pink","impulsive","harmonic"];
nR=50; random_seed=20260929;

p=gcp('nocreate'); if isempty(p), parpool('local',4); end

nCell=20;
outLong=cell(1,nCell); outSum=cell(1,nCell); tag=cell(1,nCell);
parfor idx=1:nCell
  ni=ceil(idx/5); si=idx-(ni-1)*5;
  nt=noiseList(ni); snrDb=snrList(si);
  rowsL=strings(0,1); rowsS=strings(0,1);
  for r=1:nR
    seed=random_seed+100000+r+1000*si+10000*ni;
    [clean,noisy]=make_case(fs,dur,rot,ff,resHz,resBand,damp,jit,nt,snrDb,seed);
    x=noisy(:).'; N=numel(x);
    [cand,~]=fz_gini_recall(x,fs,opts);
    X=fft(x-mean(x),N);
    xn=fz_bandpass_mask(X,N,cand(1,3),cand(1,4),fs);
    bw=cand(1,2); alpha0=opts.alpha_scale*fs/bw; Kfix=4;
    [u,~,~,~]=fz_vmd(xn,alpha0,opts.vmd_tau,Kfix,opts.vmd_DC,opts.vmd_init,opts.vmd_tol,opts.vmd_max_iter);
    imfs=u.';
    res=fz_mode_subset_select(imfs,fs,ff,opts);
    eMask=false(1,Kfix); eMask(res.keep)=true; eCode=mask_code(eMask);
    allEnergy=sum(sum(imfs,1).^2);
    thnrV=nan(1,15); snrV=nan(1,15); rrmseV=nan(1,15); corrV=nan(1,15); erV=nan(1,15); nV=zeros(1,15);
    ref=fft_bp(clean,fs,resBand);
    for code=1:15
      m=code_mask(code,Kfix); nV(code)=nnz(m);
      recon=sum(imfs(m,:),1);
      [A,fq]=fz_amp_env_spectrum(recon,fs);
      R=fz_thnr(A,fq,ff,opts); thnrV(code)=R.thnr;
      est=fft_bp(recon(:),fs,resBand); err=ref-est;
      snrV(code)=10*log10(sum(ref.^2)/max(sum(err.^2),eps));
      rrmseV(code)=sqrt(mean(err.^2))/max(sqrt(mean(ref.^2)),eps);
      cc=corrcoef(ref,est); corrV(code)=cc(1,2);
      erV(code)=sum(recon.^2)/max(allEnergy,eps);
    end
    [oracleSnr,oCode]=max(snrV);
    eSnr=snrV(eCode); allSnr=snrV(15); regret=oracleSnr-eSnr;
    srtV=sort(snrV,'descend'); eInTop3=eSnr>=srtV(3)-1e-9;
    okFin=isfinite(thnrV)&isfinite(snrV);
    if nnz(okFin)>2, sp=corr(thnrV(okFin).',snrV(okFin).','type','Spearman'); else sp=NaN; end
    for code=1:15
      rowsL(end+1)=sprintf('%s,%d,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f', ...
        char(nt),snrDb,r,code,nV(code),thnrV(code),snrV(code),rrmseV(code),corrV(code),erV(code)); %#ok<AGROW>
    end
    rowsS(end+1)=sprintf('%s,%d,%d,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%d,%d,%.6f,%.3f,%.3f', ...
      char(nt),snrDb,r,eCode,oCode,nV(eCode),eSnr,oracleSnr,allSnr,regret, ...
      double(eCode==oCode),double(eInTop3),sp,alpha0,bw); %#ok<AGROW>
  end
  outLong{idx}=rowsL; outSum{idx}=rowsS; tag{idx}=sprintf('%s_%d',char(nt),snrDb);
end

outDir='C:\Users\Zhi\Doubao\chats\2026-09-21\new-chat';
fL=fopen(fullfile(outDir,'oracle_subset_long.csv'),'w');
fprintf(fL,'noise_type,input_snr_db,repetition,code,nmask,thnr_db,snr_out_db,rrmse,correlation,energy_ratio\n');
fS=fopen(fullfile(outDir,'oracle_summary.csv'),'w');
fprintf(fS,'noise_type,input_snr_db,repetition,e_mask,oracle_mask,e_nmask,e_snr,oracle_snr,all_snr,regret_db,e_eq_oracle,e_in_top3,spearman_thnr_snr,alpha0,bw\n');
for idx=1:nCell
  fprintf(fL,'%s\n',outLong{idx});
  fprintf(fS,'%s\n',outSum{idx});
end
fclose(fL); fclose(fS);
fprintf('ALL DONE\n');
end

function c=mask_code(m), c=0; for b=1:numel(m), if m(b), c=c+2^(b-1); end, end, end
function m=code_mask(code,K), m=false(1,K); tmp=code; for b=1:K, m(b)=bitand(tmp,1)==1; tmp=bitshift(tmp,-1); end, end

function [clean,noisy]=make_case(fs,dur,rot,ff,resHz,resBand,damp,jit,nt,snrDb,seed)
rng(seed,'twister');
n=round(dur*fs); t=(0:n-1)'/fs;
period=1/ff;
impactTimes=(0:period:dur)';
impactTimes=impactTimes+jit*period*randn(size(impactTimes));
impactTimes=impactTimes(impactTimes>=0&impactTimes<dur);
impulses=zeros(n,1);
idx=min(n,max(1,round(impactTimes*fs)+1));
impulses(idx)=1+0.15*randn(size(idx));
ringLength=min(n,round(0.05*fs));
tr=(0:ringLength-1)'/fs;
ring=exp(-2*pi*damp*resHz*tr).*sin(2*pi*resHz*tr);
faultComponent=conv(impulses,ring,'full'); faultComponent=faultComponent(1:n);
background=0.08*sin(2*pi*rot*t)+0.04*sin(2*pi*2*rot*t+0.4);
clean=faultComponent+background;
noise=make_noise(nt,n,fs,ff);
signalPower=mean(faultComponent.^2); noisePower=mean(noise.^2);
scale=sqrt(signalPower/max(noisePower,eps)/10^(snrDb/10));
noisy=clean+scale*noise;
end

function noise=make_noise(nt,n,fs,ff)
t=(0:n-1)'/fs;
switch string(nt)
  case "white", noise=randn(n,1);
  case "pink"
    spectrum=zeros(n,1); nPos=n/2-1; w=1./sqrt((1:nPos).');
    halfSpec=w.*exp(1i*2*pi*rand(nPos,1));
    spectrum(1)=0; spectrum(2:nPos+1)=halfSpec;
    spectrum(n/2+1)=0; spectrum(n/2+2:n)=conj(flipud(halfSpec));
    noise=real(ifft(spectrum));
  case "impulsive"
    noise=0.2*randn(n,1); count=max(3,round(n/fs*12));
    ii=randperm(n,min(count,n)); noise(ii)=noise(ii)+8*randn(numel(ii),1);
  case "harmonic"
    noise=randn(n,1)*0.15+sin(2*pi*0.95*ff*t)+0.7*sin(2*pi*1.05*ff*t+0.7);
end
noise=noise-mean(noise); noise=noise/max(std(noise),eps);
end

function y=fft_bp(x,fs,band)
n=numel(x); X=fft(x); f=(0:n-1)'*fs/n;
mask=(f>=band(1)&f<=band(2))|(f>=fs-band(2)&f<=fs-band(1));
y=real(ifft(X.*mask)); y=y-mean(y);
end
