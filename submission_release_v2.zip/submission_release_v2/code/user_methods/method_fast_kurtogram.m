﻿function [y, meta] = method_fast_kurtogram(x, fs, ctx)
%METHOD_FAST_KURTOGRAM  Fast Kurtogram with 1/3-binary tree (Antoni, 2007).
%
%   Implements the Fast Kurtogram using the 1/3-binary tree filter bank
%   described in Antoni (2007).  At each decomposition level the positive
%   frequency band [0, fs/2] is divided into 3*2^(lv-1) equal-width
%   sub-bands via complex demodulation and zero-phase low-pass filtering
%   with a raised-cosine transition.  The sub-band with the maximum
%   spectral kurtosis of the complex envelope is selected.
%
%   Spectral kurtosis estimator (for complex envelope c):
%       K = <|c|^4> / <|c|^2>^2 - 2
%
%   Reference:
%       J. Antoni, "Fast computation of the kurtogram for the detection
%       of transient faults," Mechanical Systems and Signal Processing,
%       21(1), pp. 108-124, 2007.  DOI: 10.1016/j.ymssp.2005.12.002
%
%   y = method_fast_kurtogram(x, fs, ctx) returns the real band-passed
%   signal of the selected sub-band.

arguments
    x (:,1) double
    fs (1,1) double {mustBePositive}
    ctx (1,1) struct
end

thisDir = fileparts(mfilename('fullpath'));
addpath(thisDir);

ticId = tic;

maxLevel = 7;
minBwHz = 100;   % minimum sub-band bandwidth
minFcHz = 50;    % minimum centre frequency (separate from bandwidth)

bands = kurtogram_bands(x, fs, maxLevel, minBwHz, minFcHz);

bestKurt = -Inf;
bestBand = [];
for i = 1:numel(bands)
    env = bands(i).envelope;
    % spectral kurtosis of complex envelope
    abs2 = abs(env).^2;
    m2 = mean(abs2);
    m4 = mean(abs2.^2);
    sk = m4 / (m2^2 + eps) - 2;
    if sk > bestKurt
        bestKurt = sk;
        bestBand = bands(i);
    end
end

if isempty(bestBand)
    y = x(:);
    meta = struct('method','fast_kurtogram','selected_band_hz',[0 fs/2], ...
        'spectral_kurtosis',NaN,'level',NaN,'band_index',NaN, ...
        'tree',"",'n_bands_scanned',0, ...
        'elapsed_s',toc(ticId),'status',"failed");
    return;
end

y = bestBand.real_signal(:);
meta = struct('method','fast_kurtogram', ...
    'selected_band_hz',[bestBand.fl_hz bestBand.fh_hz], ...
    'centre_frequency_hz',bestBand.fc_hz, ...
    'bandwidth_hz',bestBand.bw_hz, ...
    'level',bestBand.level, ...
    'band_index',bestBand.band_index, ...
    'tree',bestBand.tree, ...
    'n_bands_scanned',numel(bands), ...
    'spectral_kurtosis',bestKurt, ...
    'elapsed_s',toc(ticId),'status',"ok");
end
