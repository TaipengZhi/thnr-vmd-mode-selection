function bands = kurtogram_bands(x, fs, maxLevel, minBwHz, minFcHz)
%KURTOGRAM_BANDS  1/3-binary tree band decomposition for Fast Kurtogram.
%
%   bands = kurtogram_bands(x, fs, maxLevel, minBwHz, minFcHz)
%
%   Implements the 1/3-binary tree structure described in Antoni (2007).
%   At level lv (1-indexed), the positive frequency band [0, fs/2] is
%   divided into n = 3*2^(lv-1) equal-width sub-bands, each with
%   bandwidth bw = fs/(3*2^lv).  This is the standard "1/3-binary"
%   resolution used by the Fast Kurtogram, interpolating between the
%   coarse binary tree and the finer 1/3-octave tree.
%
%   Each band is extracted via complex demodulation to baseband followed
%   by zero-phase FFT low-pass filtering with a raised-cosine transition
%   band (not an ideal rectangle).
%
%   Reference:
%       J. Antoni, "Fast computation of the kurtogram for the detection
%       of transient faults," Mechanical Systems and Signal Processing,
%       21(1), pp. 108-124, 2007.
%
%   Output struct array fields:
%       level       decomposition level (1..maxLevel)
%       band_index  sub-band index within level (1..3*2^(lv-1))
%       tree        "1/3-binary"
%       fc_hz       centre frequency
%       bw_hz       bandwidth
%       fl_hz       lower edge
%       fh_hz       upper edge
%       envelope    complex analytic envelope at baseband
%       real_signal real band-passed signal

arguments
    x (:,1) double
    fs (1,1) double {mustBePositive}
    maxLevel (1,1) double {mustBePositive,mustBeInteger} = 7
    minBwHz (1,1) double {mustBeNonnegative} = 100
    minFcHz (1,1) double {mustBeNonnegative} = 50
end

x = x(:).';
N = numel(x);
t = (0:N-1) / fs;
x = x - mean(x);

% frequency axis (centred)
freqs = (0:N-1) * fs / N;
freqs(freqs > fs/2) = freqs(freqs > fs/2) - fs;
absFreq = abs(freqs);

bands = struct([]);
idx = 0;

for lv = 1:maxLevel
    % 1/3-binary tree: 3*2^(lv-1) bands over [0, fs/2]
    nBands = 3 * 2^(lv - 1);
    bw = fs / (3 * 2^lv);
    if bw < minBwHz
        continue;
    end
    transition = bw / 4;  % raised-cosine transition width
    lpMask = raised_cosine_mask(absFreq, bw/2, transition);

    for b = 1:nBands
        fc = (b - 0.5) * bw;
        % separate minimum centre-frequency check (not bandwidth)
        if fc < minFcHz || fc > fs/2 - minFcHz
            continue;
        end
        fl = fc - bw/2;
        fh = fc + bw/2;

        % complex demodulation to baseband
        demod = x .* exp(-1i * 2 * pi * fc * t);
        Dfft = fft(demod, N);
        Dfft = Dfft .* lpMask;
        envelope = ifft(Dfft, N);

        % real band-passed signal (modulate back)
        realSig = 2 * real(envelope .* exp(1i * 2 * pi * fc * t));

        idx = idx + 1;
        bands(idx).level = lv; %#ok<AGROW>
        bands(idx).band_index = b;
        bands(idx).tree = "1/3-binary";
        bands(idx).fc_hz = fc;
        bands(idx).bw_hz = bw;
        bands(idx).fl_hz = fl;
        bands(idx).fh_hz = fh;
        bands(idx).envelope = envelope;
        bands(idx).real_signal = realSig;
    end
end
end

function mask = raised_cosine_mask(f, fc, transition)
%RAISED_COSINE_MASK  Zero-phase low-pass mask with raised-cosine transition.
%   f >= 0 (absolute frequencies).  Passband [0, fc] is 1; transition
%   (fc, fc+transition] uses half-cosine roll-off; above is 0.
mask = ones(size(f));
tz = f > fc & f <= fc + transition;
mask(tz) = 0.5 * (1 + cos(pi * (f(tz) - fc) / transition));
mask(f > fc + transition) = 0;
end
