function [e, a] = ar_whiten(x, order)
%AR_WHITEN  AR pre-whitening via Levinson-Durbin (no toolbox required).
%
%   [e, a] = ar_whiten(x, order) fits an AR(order) model to x using the
%   autocorrelation method and returns the prediction error e (pre-whitened
%   signal) and the AR coefficients a (a(1)=1).
%
%   This removes deterministic sinusoidal components so that subsequent
%   envelope analysis is not dominated by shaft or gear meshing tones.

x = x(:).';
N = numel(x);
x = x - mean(x);

% autocorrelation via FFT
nfft = 2^nextpow2(2*N);
X = fft(x, nfft);
R = ifft(abs(X).^2);
R = real(R(1:order+1));

% Levinson-Durbin
a = zeros(1, order+1);
a(1) = 1;
E = R(1);
for k = 1:order
    lambda = -sum(a(1:k) .* R(k+1:-1:2)) / (E + eps);
    a(1:k+1) = a(1:k+1) + lambda * [0, a(k:-1:1)];
    E = (1 - lambda^2) * E;
end

% prediction error
e = filter(a, 1, x);
% scale to preserve energy roughly
e = e * sqrt(var(x) / (var(e) + eps));
end
