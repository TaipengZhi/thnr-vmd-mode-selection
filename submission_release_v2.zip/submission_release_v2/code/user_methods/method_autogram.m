﻿function [y, meta] = method_autogram(x, fs, ctx)
%METHOD_AUTOGRAM  Autogram based on unbiased autocorrelation (Moshrefzadeh & Fasana, 2018).
%
%   Implements the Autogram as described in:
%       A. Moshrefzadeh and A. Fasana, "The Autogram: An effective approach
%       for selecting the optimal squared envelope band in bearing fault
%       diagnosis," Mechanical Systems and Signal Processing, 104,
%       pp. 576-597, 2018.  DOI: 10.1016/j.ymssp.2017.12.009
%
%   Core steps (differentiating from kurtogram):
%     1. AR pre-whitening to remove deterministic discrete-frequency
%        components (shaft, gear mesh).
%     2. 1/3-binary tree filter-bank decomposition.
%     3. For each sub-band, compute the squared envelope via the analytic
%        signal.
%     4. Compute the UNBIASED autocorrelation of the squared envelope:
%           R(k) = (1/(N-k)) * sum_{n=1}^{N-k} e2(n) * e2(n+k),  k >= 1
%        This is the defining step of the Autogram; it is NOT the envelope
%        spectrum skewness-kurtosis product.
%     5. The Autogram value is the kurtosis of the positive-lag
%        autocorrelation R(k), k = 1..Kmax.  Periodic impulses produce
%        sharp peaks in R(k) at multiples of the fault period, raising
%        the kurtosis.
%     6. Select the sub-band with maximum Autogram value and apply the
%        corresponding zero-phase band-pass to the ORIGINAL (non-pre-
%        whitened) signal.
%
%   y = method_autogram(x, fs, ctx) returns the band-passed signal.

arguments
    x (:,1) double
    fs (1,1) double {mustBePositive}
    ctx (1,1) struct
end

thisDir = fileparts(mfilename('fullpath'));
addpath(thisDir);

ticId = tic;
x = x(:).';

% --- Step 1: AR pre-whitening ---
arOrder = 30;
xw = ar_whiten(x, arOrder);

% --- Step 2: 1/3-binary tree filter bank ---
maxLevel = 7;
minBwHz = 100;
minFcHz = 50;
bands = kurtogram_bands(xw, fs, maxLevel, minBwHz, minFcHz);

% maximum autocorrelation lag: 0.1 s of data (covers several fault periods
% for typical bearing characteristic frequencies down to ~50 Hz)
Kmax = floor(0.1 * fs);

bestAuto = -Inf;
bestBand = [];
bestSkew = NaN;
bestKurt = NaN;

for i = 1:numel(bands)
    sig = bands(i).real_signal;

    % --- Step 3: squared envelope ---
    e2 = abs(hilbert(sig)).^2;
    e2 = e2 - mean(e2);
    N = numel(e2);

    % --- Step 4: unbiased autocorrelation (positive lags only) ---
    % R(k) = (1/(N-k)) * sum_{n=1}^{N-k} e2(n)*e2(n+k)
    % Computed via FFT for efficiency, then corrected for bias.
    nfft = 2^nextpow2(2*N);
    E2fft = fft(e2, nfft);
    Rfull = real(ifft(abs(E2fft).^2));
    % raw (biased) autocorrelation for lags 0..Kmax
    Rraw = Rfull(1:Kmax+1);
    % convert to unbiased: divide by (N-k)
    kIdx = (0:Kmax).';
    Nunbiased = max(N - kIdx, 1);
    R = Rraw(:) ./ Nunbiased;
    % exclude lag 0 (DC energy), keep positive lags 1..Kmax
    Rpos = R(2:end);

    % --- Step 5: Autogram value = kurtosis of positive-lag autocorrelation ---
    m = mean(Rpos);
    s = std(Rpos) + eps;
    kurt = mean(((Rpos - m)/s).^4);
    skew = mean(((Rpos - m)/s).^3);
    autoVal = kurt;   % Autogram: kurtosis of unbiased autocorrelation

    if autoVal > bestAuto
        bestAuto = autoVal;
        bestBand = bands(i);
        bestSkew = skew;
        bestKurt = kurt;
    end
end

if isempty(bestBand)
    y = x(:);
    meta = struct('method','autogram','selected_band_hz',[0 fs/2], ...
        'autogram_value',NaN,'autocorr_kurtosis',NaN,'autocorr_skewness',NaN, ...
        'ar_order',arOrder,'km_max',Kmax,'level',NaN,'band_index',NaN, ...
        'tree',"",'n_bands_scanned',0, ...
        'elapsed_s',toc(ticId),'status',"failed");
    return;
end

% --- Step 6: apply band-pass to ORIGINAL signal (same raised-cosine filter) ---
fc = bestBand.fc_hz;
bw = bestBand.bw_hz;
N = numel(x);
t = (0:N-1) / fs;
demod = (x - mean(x)) .* exp(-1i * 2 * pi * fc * t);
Dfft = fft(demod, N);
freqs = (0:N-1) * fs / N;
freqs(freqs > fs/2) = freqs(freqs > fs/2) - fs;
absFreq = abs(freqs);
transition = bw / 4;
lpMask = ones(size(absFreq));
tz = absFreq > bw/2 & absFreq <= bw/2 + transition;
lpMask(tz) = 0.5 * (1 + cos(pi * (absFreq(tz) - bw/2) / transition));
lpMask(absFreq > bw/2 + transition) = 0;
Dfft = Dfft .* lpMask;
envelope = ifft(Dfft, N);
y = (2 * real(envelope .* exp(1i * 2 * pi * fc * t))).';

meta = struct('method','autogram', ...
    'selected_band_hz',[bestBand.fl_hz bestBand.fh_hz], ...
    'centre_frequency_hz',fc, ...
    'bandwidth_hz',bw, ...
    'level',bestBand.level, ...
    'band_index',bestBand.band_index, ...
    'tree',bestBand.tree, ...
    'n_bands_scanned',numel(bands), ...
    'autogram_value',bestAuto, ...
    'autocorr_kurtosis',bestKurt, ...
    'autocorr_skewness',bestSkew, ...
    'km_max',Kmax, ...
    'ar_order',arOrder, ...
    'elapsed_s',toc(ticId),'status',"ok");
end
