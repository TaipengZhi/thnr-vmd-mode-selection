﻿function [y, meta] = method_proposed(x, fs, ctx)
%METHOD_PROPOSED Adapter for the SE-Gini blind screening + THNR-guided
%   VMD reconstruction method (JVC route A: THNR subset search).
%
%   y = method_proposed(x, fs, ctx) returns the reconstructed fault-band
%   signal y. ctx carries:
%       fault_frequency_assumed_hz  assumed BPFO/BPFI/BSF (Hz)
%       variant                     "A".."G" ablation stage
%       frozen_parameters           struct from build_calibration / fz_defaults
%       calibration_overrides       optional overrides used by build_calibration
%
%   消融阶梯（严格单因素，每一步只在上一步基础上增加一个模块）:
%       A  原始信号直通，不做任何处理
%       B  A + SE-Gini 盲筛，取 Gini 排名第一(top-1)频带并做带通输出
%       C  B + 固定参数 VMD（K=4, alpha=alpha0）后对全部模态求和
%       D  C + 按 THNR 只保留单一最佳模态
%       E  D + 在 top-1 频带、固定 K/alpha 下对模态子集做穷举选择
%       F  E + 在 top-1 频带（频带仍固定为 Gini top-1）上改用序列化
%              K-alpha 寻优得到 Kstar/alphaStar，再跑最终 VMD 并做模态子集穷举
%       G  F + 放开为多候选频带 THNR 重排序（即完整 fz_pipeline）
%
%   NOTE: The full pipeline (G) uses THNR for band ranking, K-alpha search
%   and mode-subset selection. There is no FGGI weighting or ESNR greedy
%   stop criterion in this route-A implementation.

arguments
    x (:,1) double
    fs (1,1) double {mustBePositive}
    ctx (1,1) struct
end

% ---- locate frozen v2.1 (client or parallel worker) -------------------
addpath(locate_frozen_dir());

opts = fz_defaults();
% apply overrides (frozen_parameters from build_calibration, or
% calibration_overrides used during the calibration run itself)
sources = {};
if isfield(ctx,'frozen_parameters') && isstruct(ctx.frozen_parameters) && ~isempty(ctx.frozen_parameters)
    sources{end+1} = ctx.frozen_parameters;
end
if isfield(ctx,'calibration_overrides') && isstruct(ctx.calibration_overrides) && ~isempty(ctx.calibration_overrides)
    sources{end+1} = ctx.calibration_overrides;
end
for s = 1:numel(sources)
    fp = sources{s};
    if isfield(fp,'B') && ~isempty(fp.B), opts.band_candidate_num = double(fp.B); end
    if isfield(fp,'H') && ~isempty(fp.H), opts.harmonic_order = double(fp.H); end
    if isfield(fp,'lambda_K') && ~isempty(fp.lambda_K), opts.lambda_K = double(fp.lambda_K); end
    if isfield(fp,'K_list') && ~isempty(fp.K_list), opts.K_list = double(fp.K_list); end
    if isfield(fp,'K_range') && ~isempty(fp.K_range), opts.K_list = double(fp.K_range); end
    if isfield(fp,'alpha_min_ratio') && ~isempty(fp.alpha_min_ratio), opts.alpha_min_ratio = double(fp.alpha_min_ratio); end
    if isfield(fp,'alpha_max_ratio') && ~isempty(fp.alpha_max_ratio), opts.alpha_max_ratio = double(fp.alpha_max_ratio); end
    if isfield(fp,'alpha_num') && ~isempty(fp.alpha_num), opts.alpha_num = double(fp.alpha_num); end
    if isfield(fp,'df_tol_hz') && ~isempty(fp.df_tol_hz)
        opts.delta_ff_coef = double(fp.df_tol_hz) / max(ctx.fault_frequency_assumed_hz, eps);
    end
end

ff = double(ctx.fault_frequency_assumed_hz);
variant = upper(string(ctx.variant));

% fz_* pipeline expects a row signal and produces a row FFT/mask; align here
x = x(:).';
N = numel(x);

ticId = tic;
switch variant
    case "A"
        y = x(:);
        meta = struct('stage',"A",'selected_band_hz',[NaN NaN],'K',0,'alpha',0,'selected_mode_count',1);

    case "B"
        [cand, ~] = fz_gini_recall(x, fs, opts);
        Xfft = fft(x - mean(x), numel(x));
        xb = fz_bandpass_mask(Xfft, numel(x), cand(1,3), cand(1,4), fs);
        y = xb(:);
        meta = struct('stage',"B",'selected_band_hz',[cand(1,3) cand(1,4)], ...
            'K',0,'alpha',0,'selected_mode_count',1);

    case "C"
        [cand, ~] = fz_gini_recall(x, fs, opts);
        Xfft = fft(x - mean(x), numel(x));
        xn = fz_bandpass_mask(Xfft, numel(x), cand(1,3), cand(1,4), fs);
        bw = cand(1,2);
        alpha0 = opts.alpha_scale * fs / bw;
        Kfix = 4;
        [u,~,~,~] = fz_vmd(xn, alpha0, opts.vmd_tau, Kfix, opts.vmd_DC, opts.vmd_init, opts.vmd_tol, opts.vmd_max_iter);
        % u is N x K; sum across modes -> column vector
        y = sum(u, 2);
        meta = struct('stage',"C",'selected_band_hz',[cand(1,3) cand(1,4)], ...
            'K',Kfix,'alpha',alpha0,'selected_mode_count',Kfix);

    case "D"
        [cand, ~] = fz_gini_recall(x, fs, opts);
        Xfft = fft(x - mean(x), numel(x));
        xn = fz_bandpass_mask(Xfft, numel(x), cand(1,3), cand(1,4), fs);
        bw = cand(1,2);
        alpha0 = opts.alpha_scale * fs / bw;
        Kfix = 4;
        [u,~,~,~] = fz_vmd(xn, alpha0, opts.vmd_tau, Kfix, opts.vmd_DC, opts.vmd_init, opts.vmd_tol, opts.vmd_max_iter);
        imfs = u.';
        bestT = -inf; bestY = imfs(1,:);
        for k = 1:size(imfs,1)
            [A,fq] = fz_amp_env_spectrum(imfs(k,:), fs);
            r = fz_thnr(A, fq, ff, opts);
            if r.thnr > bestT, bestT = r.thnr; bestY = imfs(k,:); end
        end
        y = bestY(:);
        meta = struct('stage',"D",'selected_band_hz',[cand(1,3) cand(1,4)], ...
            'K',Kfix,'alpha',alpha0,'selected_mode_count',1);

    case "E"
        R = fz_pipeline_fixedK(x, fs, ff, opts);
        y = R.xrec(:);
        meta = struct('stage',"E",'selected_band_hz',[R.selected_band(3) R.selected_band(4)], ...
            'K',R.Kstar,'alpha',R.alphaStar,'selected_mode_count',numel(R.keep_modes));

    case "F"
        % F 阶段：与 E 共用 Gini top-1 频带（selIdx=1），唯一差别是把 E 的
        % 固定 K=4/alpha0 换成 fz_sequential_optimize 在该 top-1 频带上序列化
        % 寻优得到的 Kstar/alphaStar，随后仍做模态子集穷举；选带不做重排序。
        R = fz_pipeline_top1_sequential(x, fs, ff, opts);
        y = R.xrec(:);
        meta = struct('stage',"F",'selected_band_hz',[R.selected_band(3) R.selected_band(4)], ...
            'K',R.Kstar,'alpha',R.alphaStar,'selected_mode_count',numel(R.keep_modes));

    case "G"
        % G 阶段：完整流水线 fz_pipeline，相对 F 的唯一差别是放开为多候选频带
        % 的 THNR 重排序（选带不再固定为 Gini top-1）。
        R = fz_pipeline(x, fs, ff, opts);
        y = R.xrec(:);
        meta = struct('stage',"G",'selected_band_hz',[R.selected_band(3) R.selected_band(4)], ...
            'K',R.Kstar,'alpha',R.alphaStar,'selected_mode_count',numel(R.keep_modes));
    otherwise
        error('method_proposed:BadVariant', 'Unknown variant: %s', variant);
end

meta.elapsed_s = toc(ticId);
meta.status = "ok";
end

function R = fz_pipeline_fixedK(x, fs, ff, opts)
% E-stage: single-factor ablation. Same Gini top-1 band as B/C/D, same fixed
% K=4 and alpha=alpha0; only the mode combination rule changes (subset
% exhaustive instead of single-best). This isolates the subset-search effect.
[cand, ~] = fz_gini_recall(x, fs, opts);
N = numel(x);
X = fft(x - mean(x), N);
selIdx = 1;  % Gini top-1, identical to B/C/D
xn = fz_bandpass_mask(X, N, cand(selIdx,3), cand(selIdx,4), fs);
bw = cand(selIdx,2);
alpha0 = opts.alpha_scale * fs / bw;
Kstar = 4;
[u,~,~,~] = fz_vmd(xn, alpha0, opts.vmd_tau, Kstar, opts.vmd_DC, opts.vmd_init, opts.vmd_tol, opts.vmd_max_iter);
imfs = u.';
res = fz_mode_subset_select(imfs, fs, ff, opts);
R = struct('selected_band',cand(selIdx,:),'Kstar',Kstar,'alphaStar',alpha0, ...
    'keep_modes',res.keep,'xrec',res.recon);
end

function R = fz_pipeline_top1_sequential(x, fs, ff, opts)
% F 阶段：严格单因素消融。与 E(fz_pipeline_fixedK) 使用完全相同的 Gini top-1
% 频带带通；唯一差别是把 E 的固定 K=4 / alpha=alpha0 换成 fz_sequential_optimize
% 在该 top-1 频带上序列化寻优得到的 Kstar/alphaStar，再用它们跑最终 fz_vmd，
% 最后做模态子集穷举。注意：选带仍固定为 Gini 第一名(selIdx=1)，不做 fz_pipeline
% 里的多候选频带 THNR 重排序（那是 G 阶段才放开的模块）。
[cand, ~] = fz_gini_recall(x, fs, opts);
N = numel(x);
X = fft(x - mean(x), N);
selIdx = 1;  % Gini top-1，与 B/C/D/E 完全一致
xn = fz_bandpass_mask(X, N, cand(selIdx,3), cand(selIdx,4), fs);
bw = cand(selIdx,2);
% 在固定的 top-1 频带上做序列化 K-alpha 寻优（lambdaK 缺省取 opts.lambda_K）
opt = fz_sequential_optimize(xn, bw, ff, fs, opts);
Kstar = opt.Kstar;
alphaStar = opt.alphaStar;
% 用寻优得到的 Kstar/alphaStar 跑最终 VMD
[u,~,~,~] = fz_vmd(xn, alphaStar, opts.vmd_tau, Kstar, opts.vmd_DC, opts.vmd_init, opts.vmd_tol, opts.vmd_max_iter);
imfs = u.';
% 模态子集穷举
res = fz_mode_subset_select(imfs, fs, ff, opts);
R = struct('selected_band',cand(selIdx,:),'Kstar',Kstar,'alphaStar',alphaStar, ...
    'keep_modes',res.keep,'xrec',res.recon);
end

function t = band_thnr(X, N, fl, fh, fs, ff, opts)
xb = fz_bandpass_mask(X, N, fl, fh, fs);
[A,fq] = fz_amp_env_spectrum(xb, fs);
t = fz_thnr(A,fq,ff,opts).thnr;
end
