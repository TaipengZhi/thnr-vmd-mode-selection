function root = locate_frozen_dir()
%LOCATE_FROZEN_DIR Locate the frozen_v21 folder on client or parallel worker.
%   On a parallel worker the attached frozen_v21 folder is already on the
%   path, so prefer which(); the relative-to-adapter path only exists on the
%   client and fails inside the worker's temp folder.
p = which('fz_pipeline');
if ~isempty(p)
    root = fileparts(p);
else
    thisDir = fileparts(mfilename('fullpath'));
    root = fullfile(thisDir, '..', '..', '..', 'frozen_v21');
end
if ~exist(root, 'dir')
    error('locate_frozen_dir:Missing', 'frozen_v21 not found at %s', root);
end
end
