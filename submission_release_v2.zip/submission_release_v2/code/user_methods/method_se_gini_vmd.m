function [y, meta] = method_se_gini_vmd(x, fs, ctx)
%METHOD_SE_GINI_VMD Baseline: SE-Gini blind band recall -> fixed VMD
%(K=4, alpha=alpha0) -> sum of all IMFs. No mode selection, no THNR.
arguments
    x (:,1) double
    fs (1,1) double {mustBePositive}
    ctx (1,1) struct
end
addpath(locate_frozen_dir());
opts = fz_defaults();

ticId = tic;
x = x(:).'; N = numel(x);
[cand, ~] = fz_gini_recall(x, fs, opts);
Xfft = fft(x - mean(x), N);
xn = fz_bandpass_mask(Xfft, N, cand(1,3), cand(1,4), fs);
bw = cand(1,2);
alpha0 = opts.alpha_scale * fs / bw;
Kfix = 4;
[u,~,~,~] = fz_vmd(xn, alpha0, opts.vmd_tau, Kfix, opts.vmd_DC, ...
    opts.vmd_init, opts.vmd_tol, opts.vmd_max_iter);
y = sum(u, 2);
meta = struct('method','se_gini_vmd','selected_band_hz',[cand(1,3) cand(1,4)], ...
    'K',Kfix,'alpha',alpha0,'selected_mode_count',Kfix, ...
    'elapsed_s',toc(ticId),'status',"ok");
end
