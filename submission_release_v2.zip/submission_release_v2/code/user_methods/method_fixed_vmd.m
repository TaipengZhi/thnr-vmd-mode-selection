function [y, meta] = method_fixed_vmd(x, fs, ctx)
%METHOD_FIXED_VMD Baseline: VMD with fixed K=4 and alpha=alpha0 on the raw
%signal (no band selection, no mode selection, all IMFs summed).
arguments
    x (:,1) double
    fs (1,1) double {mustBePositive}
    ctx (1,1) struct
end
addpath(locate_frozen_dir());
opts = fz_defaults();

ticId = tic;
x = x(:).'; N = numel(x);
Kfix = 4;
bw = fs/4;                       % nominal band width (no band selection)
alpha0 = opts.alpha_scale * fs / bw;
[u,~,~,~] = fz_vmd(x, alpha0, opts.vmd_tau, Kfix, opts.vmd_DC, ...
    opts.vmd_init, opts.vmd_tol, opts.vmd_max_iter);
y = sum(u, 2);
meta = struct('method','fixed_vmd','K',Kfix,'alpha',alpha0, ...
    'selected_mode_count',Kfix,'elapsed_s',toc(ticId),'status',"ok");
end
