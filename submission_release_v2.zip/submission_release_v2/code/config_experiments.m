function cfg = config_experiments(mode)
%CONFIG_EXPERIMENTS Build a reproducible configuration for S1-S5.

arguments
    mode (1,1) string {mustBeMember(mode,["smoke","production"])} = "smoke"
end

projectDir = fileparts(mfilename('fullpath'));

cfg.mode = mode;
cfg.random_seed = 20260929;
cfg.output_root = fullfile(projectDir, 'results');
cfg.fail_on_missing_method = mode == "production";
cfg.frozen_parameter_file = fullfile(projectDir, 'frozen_parameters.mat');
cfg.frozen_parameters = struct();

% 完整流水线变体：默认 "E"（top-1 SES-Gini 频带 + 固定 K/alpha + 穷举非空模态子集），
% 与论文 v5 最终方法一致。F（序列 K-alpha 搜索）与 G（多候选频带重排序）经消融证明
% 无增益甚至显著降性能，仅保留为 S2 消融专用变体，不再作为 production 默认。
cfg.variant = "E";

cfg.enabled.S1 = true;
cfg.enabled.S2 = true;
cfg.enabled.S3 = true;
cfg.enabled.S4 = true;
cfg.enabled.S5 = true;

% 并行开关：默认启用并行（run_experiments 据此决定是否建立经核验的并行池）。
% 设为 false 时 run_experiments 跳过建池，parfor 全部串行执行。
cfg.parallel.enabled = true;

cfg.sim.fs = 25600;
cfg.sim.duration_s = 1.0;
cfg.sim.rotation_hz = 30;
cfg.sim.fault_frequency_hz = 107.36;
cfg.sim.resonance_hz = 4500;
cfg.sim.resonance_band_hz = [3500 5500];
cfg.sim.damping = 0.035;
cfg.sim.jitter_fraction = 0.01;
cfg.sim.snr_db = [-15 -10 -5 0 5];
cfg.sim.noise_types = ["white","pink","impulsive","harmonic"];
cfg.sim.repetitions = 50;

if mode == "smoke"
    cfg.sim.snr_db = [-10 0];
    cfg.sim.noise_types = ["white","pink"];
    cfg.sim.repetitions = 3;
end

cfg.metrics.harmonic_count = 3;
cfg.metrics.fault_tolerance_hz = 3;
cfg.metrics.background_guard_hz = 5;

cfg.frequency_bias.values = [-0.10 -0.05 -0.03 -0.01 0 0.01 0.03 0.05 0.10];
cfg.frequency_bias.snr_db = -10;
cfg.frequency_bias.noise_types = ["white","pink"];
cfg.frequency_bias.repetitions = 30;
if mode == "smoke"
    cfg.frequency_bias.values = [-0.03 0 0.03];
    cfg.frequency_bias.noise_types = "white";
    cfg.frequency_bias.repetitions = 2;
end

% S2 消融变体：严格单因素阶梯 A-G，每步只在上一步基础上增加一个模块
% （A 直通 / B +Gini top-1 带通 / C +固定VMD全模态求和 / D +单最佳模态 /
%  E +固定参数下模态子集穷举 / F E+top-1频带序列化K-alpha寻优 / G F+多候选频带THNR重排序）。
% production 与 smoke 共用此 7 变体列表；下方 smoke 分支仅覆盖 repetitions，不回退变体数量。
cfg.ablation.variants = ["A","B","C","D","E","F","G"];
cfg.ablation.snr_db = -10;
cfg.ablation.noise_types = ["white","pink"];
cfg.ablation.repetitions = 30;
if mode == "smoke"
    cfg.ablation.repetitions = 2;
end

cfg.xjtu.manifest = fullfile(projectDir, 'manifests', 'xjtu_manifest.csv');
cfg.xjtu.baseline_fraction = 0.25;
cfg.xjtu.threshold_mad_multiplier = 6;
cfg.xjtu.consecutive_alarms = 3;

cfg.cwru.manifest = fullfile(projectDir, 'manifests', 'cwru_manifest.csv');

cfg.statistics.alpha = 0.05;
cfg.statistics.bootstrap_repetitions = 2000;
if mode == "smoke"
    cfg.statistics.bootstrap_repetitions = 200;
end

if mode == "smoke"
    cfg.primary_method = "demo_guided";
    cfg.methods = struct( ...
        'name', {"demo_guided","demo_bandpass","demo_raw"}, ...
        'function_name', {"fdx.demo_guided","fdx.demo_bandpass","fdx.demo_raw"});
else
    cfg.primary_method = "proposed";
    cfg.methods = struct( ...
        'name', {"proposed","fixed_vmd","fast_kurtogram","autogram", ...
                 "two_stage_vmd","se_gini_vmd"}, ...
        'function_name', {"method_proposed","method_fixed_vmd", ...
                 "method_fast_kurtogram","method_autogram", ...
                 "method_two_stage_vmd","method_se_gini_vmd"});
end
end
