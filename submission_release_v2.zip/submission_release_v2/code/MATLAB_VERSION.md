# MATLAB and Toolbox Version Requirements

## Development Environment

- **MATLAB**: R2025a (9.18)
- **Operating System**: Windows 11 Pro (64-bit)
- **CPU**: Intel Core i7-13700H
- **RAM**: 32 GB

## Required Toolboxes

| Toolbox | Version | Used for |
|---------|---------|----------|
| Signal Processing Toolbox | 25.1 | `fft`, `hilbert`, `filter`, `pburg` |
| Parallel Computing Toolbox | 25.1 | `parfor` for batch experiments (optional) |

## Minimum Compatible Version

- **MATLAB R2021a** or later is recommended.
- The core algorithm (`method_proposed.m`, `fz_*.m`) uses only basic MATLAB
  functions and should work on R2019b or later.
- Parallel Computing Toolbox is **not required** for single-signal reproduction.
  It is only used to accelerate the full S1–S5 batch experiments.

## No External Dependencies

The release package is self-contained. It does **not** require:
- Any third-party toolboxes
- Any files from the original `D:\two_stage_vmd_fggi_project` directory
- Internet access
- MEX compilation

## Reproduction Test

Run `code/run_reproduction_smoke.m` from the release root to verify:
1. All required functions are on the path
2. `frozen_parameters.mat` loads correctly
3. Variant E runs end-to-end on a synthetic signal
4. Output structure contains expected fields

Expected result: `ALL CHECKS PASSED`.

## Notes

- The VMD implementation (`fz_vmd.m`) is a self-contained MATLAB function
  based on Dragomiretskiy and Zosso (2014). It does not call any external
  VMD toolbox.
- The Fast Kurtogram and Autogram baselines are custom approximations
  included in `code/user_methods/`. They are not the original authors'
  implementations.
- All random number generation uses `rng(seed, 'twister')` for
  reproducibility.
