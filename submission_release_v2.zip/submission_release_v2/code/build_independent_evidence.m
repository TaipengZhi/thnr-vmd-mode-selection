function build_independent_evidence()
%BUILD_INDEPENDENT_EVIDENCE  E 口径独立证据计算（不修改任何 frozen 代码）。
%  回应审稿意见 4：选择准则(THNR)与评价指标(ESNR)同源问题。
%  三类独立证据：
%   A. 半实物注入实验：真实 CWRU 正常记录为背景 + 注入已知故障分量
%      -> 有干净参考 -> 输出 SNR / RRMSE / 相关系数（完全独立于 THNR 方向）
%   B. 正常数据目标频率虚警：正常记录在假设故障频率下的 ESNR/HER 响应
%   C. 代表记录包络谱对比 + 谱平坦度(不依赖 f_f) + 非目标频率虚假峰比例
%  输出目录: C:\Users\Zhi\Doubao\chats\2026-09-21\new-chat\independent_evidence\

projectDir = 'D:\two_stage_vmd_fggi_project\sci\matlab_experiments';
cd(projectDir);
addpath(projectDir);
addpath(fullfile(projectDir, 'user_methods'));
addpath('D:\two_stage_vmd_fggi_project\frozen_v21');

outDir = 'C:\Users\Zhi\Doubao\chats\2026-09-21\new-chat\independent_evidence';
if ~isfolder(outDir), mkdir(outDir); end

cfg = config_experiments("production");
methods = cfg.methods;
M = readtable(cfg.cwru.manifest, 'TextType', 'string');
normRows = M(M.fault_type == "N", :);
faultRows = M(M.fault_type ~= "N", :);

fs = 12000; N = fs; dur = 1.0;              % 1 s 窗口（与论文协议一致）
faultTypes = ["B", "IR", "OR"];
snrs = [-10, -5];

fprintf('A. 半实物注入实验开始...\n');
rowsA = {};
for r = 1:height(normRows)
    bg = read_signal(normRows(r,:));
    bg = bg(1:N); bg = bg - mean(bg);
    ld = normRows.load(r);
    for ft = 1:3
        fr = faultRows(faultRows.fault_type == faultTypes(ft) & faultRows.load == ld, :);
        if isempty(fr), continue; end
        ff = fr.fault_frequency_hz(1);
        for s = 1:2
            snr = snrs(s);
            seed = 700000 + r*10000 + ft*1000 + s*100;
            [x, faultRef] = inject_fault(bg, fs, dur, ff, snr, seed);
            for mm = 1:numel(methods)
                ctx = mkctx(ff, cfg);
                [y, meta] = invoke_m(methods(mm), x, fs, ctx);
                met = signal_metrics(y, faultRef, fs, ctx, cfg);
                rowsA{end+1} = struct('record', normRows.record_id(r), 'load', ld, ...
                    'fault_type', faultTypes(ft), 'fault_frequency_hz', ff, 'input_snr_db', snr, ...
                    'method', methods(mm).name, 'output_snr_db', met.output_snr_db, ...
                    'rrmse', met.rrmse, 'correlation', met.correlation, ...
                    'esnr_db', met.esnr_db, 'her', met.her, 'runtime_s', meta.elapsed_s, ...
                    'status', string(meta.status), 'error_message', meta.error_message);
            end
        end
    end
    fprintf('  A: 背景记录 %d/%d 完成\n', r, height(normRows));
end
T_A = struct2table(vertcat(rowsA{:}));
writetable(T_A, fullfile(outDir, 'independent_injection_results.csv'));
fprintf('A 完成: %d 行\n', height(T_A));

fprintf('B. 正常数据目标频率虚警...\n');
rowsB = {};
for r = 1:height(normRows)
    x = read_signal(normRows(r,:));
    x = x(1:N); x = x - mean(x);
    ld = normRows.load(r);
    for ft = 1:3
        fr = faultRows(faultRows.fault_type == faultTypes(ft) & faultRows.load == ld, :);
        ff = fr.fault_frequency_hz(1);
        for mm = 1:numel(methods)
            ctx = mkctx(ff, cfg);
            [y, meta] = invoke_m(methods(mm), x, fs, ctx);
            met = signal_metrics(y, [], fs, ctx, cfg);
            rowsB{end+1} = struct('record', normRows.record_id(r), 'load', ld, ...
                'hypothesis_fault_type', faultTypes(ft), 'hypothesis_ff_hz', ff, ...
                'method', methods(mm).name, 'esnr_db', met.esnr_db, 'her', met.her, ...
                'envelope_kurtosis', met.envelope_kurtosis, 'runtime_s', meta.elapsed_s, ...
                'status', string(meta.status), 'error_message', meta.error_message);
        end
    end
    fprintf('  B: 记录 %d/%d 完成\n', r, height(normRows));
end
T_B = struct2table(vertcat(rowsB{:}));
writetable(T_B, fullfile(outDir, 'independent_normal_falsealarm.csv'));
fprintf('B 完成: %d 行\n', height(T_B));

fprintf('C. 代表记录包络谱对比...\n');
recs = ["CWRU_B007_1", "CWRU_IR007_1", "CWRU_OR007_1"];
meth_show = ["proposed", "fixed_vmd"];
figH = figure('Position', [100 100 1400 1600], 'Visible', 'off');
rowsC = {};
for k = 1:3
    row = M(M.record_id == recs(k), :);
    x = read_signal(row(1,:)); x = x(1:N); x = x - mean(x);
    ff = row.fault_frequency_hz(1);
    ctx = mkctx(ff, cfg);
    for mm = 1:numel(meth_show)
        mn = meth_show(mm);
        mi = find(arrayfun(@(s) strcmp(s.name, mn), methods), 1);
        [y, meta] = invoke_m(methods(mi), x, fs, ctx);
        met = signal_metrics(y, [], fs, ctx, cfg);
        [sf, spur] = spectrum_diagnostics(y, fs, ff, cfg);
        rowsC{end+1} = struct('record', recs(k), 'fault_type', row.fault_type(1), ...
            'fault_frequency_hz', ff, 'method', mn, 'esnr_db', met.esnr_db, ...
            'envelope_kurtosis', met.envelope_kurtosis, 'spectral_flatness', sf, ...
            'spurious_peak_ratio_db', spur, 'runtime_s', meta.elapsed_s, ...
            'status', string(meta.status));
        subplot(3, 2, (k-1)*2 + mm);
        plot_envelope_spectrum(x, y, fs, ff, ctx, cfg, recs(k), mn);
    end
end
T_C = struct2table(vertcat(rowsC{:}));
writetable(T_C, fullfile(outDir, 'independent_spectrum_diagnostics.csv'));
print(figH, fullfile(outDir, 'supp_fig_independent_envelope_spectra'), '-dpdf');
print(figH, fullfile(outDir, 'supp_fig_independent_envelope_spectra'), '-dsvg');
print(figH, fullfile(outDir, 'supp_fig_independent_envelope_spectra'), '-dpng', '-r600');
close(figH);
fprintf('C 完成。\n');
fprintf('全部独立证据计算完成，输出到 %s\n', outDir);
end

% ---------- 冻结接口复制（自包含，不依赖 run_suite 局部函数） ----------

function ctx = mkctx(ff, cfg)
ctx = struct('fault_frequency_true_hz', double(ff), ...
    'fault_frequency_assumed_hz', double(ff), ...
    'resonance_band_hz', double(cfg.sim.resonance_band_hz), ...
    'variant', string("E"), 'rotation_hz', double(cfg.sim.rotation_hz), ...
    'clean_reference', [], 'frozen_parameters', cfg.frozen_parameters);
end

function [y, meta] = invoke_m(method, x, fs, ctx)
ticId = tic;
try
    fn = str2func(char(method.function_name));
    [y, userMeta] = fn(x(:), fs, ctx);
    validateattributes(y, {'numeric'}, {'vector', 'numel', numel(x), 'finite'});
    y = y(:);
    meta = userMeta;
    meta.elapsed_s = toc(ticId);
    if ~isfield(meta, 'status') || strlength(string(meta.status)) == 0
        meta.status = "ok";
    end
    meta.error_message = "";
catch ME
    y = nan(size(x));
    meta = struct('elapsed_s', toc(ticId), 'status', "failed: " + string(ME.identifier), ...
        'error_message', string(ME.message));
end
end

function metric = signal_metrics(y, clean, fs, ctx, cfg)
metric.output_snr_db = NaN;
metric.rrmse = NaN;
metric.correlation = NaN;
if all(isfinite(y)) && ~isempty(clean)
    ref = fft_bandpass(clean(:), fs, ctx.resonance_band_hz);
    est = fft_bandpass(y(:), fs, ctx.resonance_band_hz);
    err = ref - est;
    metric.output_snr_db = 10*log10(sum(ref.^2) / max(sum(err.^2), eps));
    metric.rrmse = sqrt(mean(err.^2)) / max(sqrt(mean(ref.^2)), eps);
    C = corrcoef(ref, est);
    if numel(C) >= 4, metric.correlation = C(1,2); end
end
if all(isfinite(y))
    env = analytic_envelope(y(:));
    env = env - mean(env);
    [metric.esnr_db, metric.her] = envelope_scores(env, fs, ...
        ctx.fault_frequency_true_hz, cfg.metrics.harmonic_count, ...
        cfg.metrics.fault_tolerance_hz, cfg.metrics.background_guard_hz);
    z = (env - mean(env)) / max(std(env), eps);
    metric.envelope_kurtosis = mean(z.^4);
else
    metric.esnr_db = NaN;
    metric.her = NaN;
    metric.envelope_kurtosis = NaN;
end
end

function [esnr, her] = envelope_scores(env, fs, ff, H, tolHz, guardHz)
n = numel(env);
nfft = 2^nextpow2(n);
Y = abs(fft(env, nfft)).^2;
f = (0:nfft-1)'*fs/nfft;
keep = f <= fs/2;
f = f(keep); Y = Y(keep);
signalMask = false(size(f));
guardMask = false(size(f));
for h = 1:H
    signalMask = signalMask | abs(f - h*ff) <= tolHz;
    guardMask = guardMask | abs(f - h*ff) <= guardHz;
end
signalEnergy = sum(Y(signalMask));
backgroundMask = f >= max(ff*0.5, 1) & f <= min((H+1)*ff, fs/2) & ~guardMask;
backgroundEnergy = sum(Y(backgroundMask));
esnr = 10*log10(signalEnergy / max(backgroundEnergy, eps));
her = signalEnergy / max(sum(Y(f >= 1 & f <= min((H+1)*ff, fs/2))), eps);
end

function y = fft_bandpass(x, fs, band)
if any(~isfinite(band)) || numel(band) ~= 2
    y = x - mean(x);
    return;
end
n = numel(x);
X = fft(x);
f = (0:n-1)'*fs/n;
mask = (f >= band(1) & f <= band(2)) | (f >= fs-band(2) & f <= fs-band(1));
y = real(ifft(X .* mask));
end

function env = analytic_envelope(x)
n = numel(x);
X = fft(x);
h = zeros(n,1);
if mod(n,2) == 0
    h([1 n/2+1]) = 1;
    h(2:n/2) = 2;
else
    h(1) = 1;
    h(2:(n+1)/2) = 2;
end
env = abs(ifft(X .* h));
end

function x = read_signal(row)
path = char(row.file_path);
if ~isfile(path)
    error('Missing data file: %s', path);
end
S = load(path, char(row.variable_name));
x = S.(char(row.variable_name));
end

function [x, faultRef] = inject_fault(bg, fs, dur, ff, snr, seed)
% v2: reference = scaled injected fault component a*s_f(t) only (no bg).
% a is normalized so 10log10(P_bp(a*s_f)/P_bp(b)) = snr. x = b + a*s_f.
rng(seed, 'twister');
n = round(fs*dur); t = (0:n-1)'/fs;
period = 1/ff;
impactTimes = (0:period:dur)';
impactTimes = impactTimes + 0.01*period*randn(size(impactTimes));
impactTimes = impactTimes(impactTimes >= 0 & impactTimes < dur);
impulses = zeros(n,1);
idx = min(n, max(1, round(impactTimes*fs)+1));
impulses(idx) = 1 + 0.15*randn(size(idx));
ringLen = min(n, round(0.05*fs));
tr = (0:ringLen-1)'/fs;
ring = exp(-2*pi*0.035*4500*tr) .* sin(2*pi*4500*tr);
faultRaw = conv(impulses, ring, 'full');
faultRaw = faultRaw(1:n);
band = [3500, 5500];
bg_bp = fft_bandpass(bg, fs, band);
fault_bp = fft_bandpass(faultRaw, fs, band);
bgPow = mean(bg_bp.^2);
faultPow = mean(fault_bp.^2);
targetPowerRatio = 10^(snr/10);
scale = sqrt(targetPowerRatio * bgPow / max(faultPow, eps));
faultRef = scale * faultRaw;
x = bg + faultRef;
end

function [sf, spurDb] = spectrum_diagnostics(y, fs, ff, cfg)
% 谱平坦度（不依赖 f_f）与虚假峰比例（非目标谐波邻域最大峰相对目标谐波峰）
env = analytic_envelope(y(:));
env = env - mean(env);
H = cfg.metrics.harmonic_count;
tol = cfg.metrics.fault_tolerance_hz;
n = numel(env);
nfft = 2^nextpow2(n);
Y = abs(fft(env, nfft)).^2;
f = (0:nfft-1)'*fs/nfft;
keep = f <= fs/2;
f = f(keep); Y = Y(keep);
% 谱平坦度
g = Y(Y > eps);
sf = exp(mean(log(g))) / max(mean(g), eps);
% 虚假峰比例：搜索范围 0.5ff 至 (H+1)ff，排除目标谐波 ±tol 邻域
lo = max(ff*0.5, 1); hi = min((H+1)*ff, fs/2);
targetMask = false(size(f));
for h = 1:H
    targetMask = targetMask | abs(f - h*ff) <= tol;
end
bandMask = f >= lo & f <= hi;
spurMask = bandMask & ~targetMask;
if any(targetMask & bandMask)
    targetPeak = max(Y(targetMask & bandMask));
else
    targetPeak = eps;
end
if any(spurMask)
    spurPeak = max(Y(spurMask));
else
    spurPeak = eps;
end
spurDb = 10*log10(spurPeak / max(targetPeak, eps));
end

function plot_envelope_spectrum(x, y, fs, ff, ctx, cfg, rec, mn)
H = cfg.metrics.harmonic_count;
tol = cfg.metrics.fault_tolerance_hz;
envs = {analytic_envelope(x(:)), analytic_envelope(y(:))};
labels = {strrep(rec,'CWRU_','') + " raw", mn + " recon"};
cols = {[0.6 0.6 0.6], [0.85 0.15 0.15]};
hold off;
for i = 1:2
    env = envs{i} - mean(envs{i});
    n = numel(env); nfft = 2^nextpow2(n);
    Y = abs(fft(env, nfft)).^2;
    f = (0:nfft-1)'*fs/nfft;
    keep = f <= fs/2;
    plot(f(keep), Y(keep), 'Color', cols{i}, 'LineWidth', 0.7); hold on;
end
for h = 1:H
    xline(h*ff, '--', [' ' num2str(h) 'f_f'], 'Color', [0 0 0], ...
        'LabelOrientation', 'horizontal', 'LabelHorizontalAlignment', 'left', ...
        'FontSize', 7);
end
xlim([0 min((H+1)*ff, fs/2)*1.1]);
ylim([0 max(Y(keep))*1.15]);
grid on; box on;
xlabel('Frequency (Hz)'); ylabel('Squared envelope spectrum');
title(sprintf('%s (f_f=%.1f Hz)', rec, ff), 'Interpreter', 'none', 'FontSize', 9);
legend(labels, 'FontSize', 7, 'Location', 'northeast');
end
