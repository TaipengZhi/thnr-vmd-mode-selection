# Confirmation Experiment Protocol v1 (frozen before run)

**Generated:** 2026-10-08, before any confirmation data was produced.
**Purpose:** Independent confirmation of the noise-dependent utility of THNR-guided VMD mode-subset selection (variant E vs variant C), using random seeds fully disjoint from all prior experiments.

This file is frozen. After the confirmation run starts, no parameter in this file may be changed based on observed results. If a change is required, the version number is incremented and the old run is discarded.

---

## 1. Code and environment

- **Code base:** `D:\two_stage_vmd_fggi_project` (frozen_v21 + sci/matlab_experiments).
- **MATLAB:** R2025a.
- **Parallel pool:** 4 local process workers; each signal processed entirely within one worker.
- **Core functions (unchanged from production E):**
  - `fz_gini_recall.m` — SES-Gini top-1 band selection (blind, no fault frequency).
  - `fz_bandpass_mask.m` — frequency-domain bandpass.
  - `fz_vmd.m` — VMD with fixed K=4, bandwidth-normalised alpha0 = alpha_scale * fs / BW_selected.
  - `fz_mode_subset_select.m` — exhaustive enumeration of 15 non-empty subsets, THNR maximisation, tie handling.
  - `fz_thnr.m` — target-harmonic-to-noise ratio on the squared-envelope magnitude spectrum.
  - `fz_amp_env_spectrum.m` — mean-removed squared-envelope magnitude spectrum.
- **alpha_scale = 200** (production default, unchanged).
- **K = 4** (fixed, unchanged).
- **H = 3** harmonic orders.
- **Frequency neighbourhood:** delta = max(3*df, 3 Hz) at fs=25600, dur=1.0 s (df=1 Hz → delta=3 Hz).
- **Envelope analysis range:** 0–500 Hz; DC and first 3 bins excluded; bins below 0.5*df excluded; shaft-frequency harmonics retained in background; harmonic windows clipped at 500 Hz boundary.
- **THNR uses squared magnitudes** (A^2), identical to production.

## 2. Variants under test (all share one VMD decomposition per signal)

| Variant | Definition |
|---|---|
| **B** | SES-Gini top-1 bandpass output, no VMD. |
| **C** | Same band, fixed-K=4 VMD, all 4 modes summed (code 15). |
| **D** | Same VMD modes, single mode with maximum THNR (among codes 1,2,4,8). |
| **E** | Same VMD modes, exhaustive 15-subset THNR maximisation (production final method). |
| **Oracle** | Same VMD modes, subset maximising output SNR (diagnostic only, not deployable). |

B, C, D, E, oracle are computed from the **same** VMD mode set for each signal, so differences are attributable solely to the selection rule.

## 3. Signal model (identical to production S1)

- fs = 25600 Hz, duration = 1.0 s.
- rotation = 30 Hz, fault frequency ff = 107.36 Hz (6205 geometry).
- resonance = 4500 Hz, resonance band [3500, 5500] Hz, damping = 0.035, ring length 0.05 s.
- jitter = 1% of period; impact amplitude = 1 + 0.15*N(0,1).
- deterministic background: 0.08*sin(2π*30t) + 0.04*sin(2π*60t+0.4).
- Noise types: white, pink (1/sqrt(f) amplitude → 1/f PSD), impulsive (0.2*Gaussian floor + ~12 impulses/s at 8*N(0,1)), harmonic (0.15*Gaussian + sin(0.95ff) + 0.7*sin(1.05ff+0.7)).
- Input SNR defined as fault-component power / noise power after scaling.
- SNR levels: -15, -10, -5, 0, +5 dB.
- Repetitions: 50 per cell. Total = 4*5*50 = 1000 signals.

## 4. Random seeds (disjoint from all prior experiments)

- **Prior seed base:** 20260929 (calibration, S1, S2, S4, oracle exploration).
  - Prior cell seed = 20260929 + 100000 + r + 1000*si + 10000*ni, range ≈ [20371930, 20415979].
- **Confirmation seed base:** 30261008.
  - Confirmation cell seed = 30261008 + 100000 + r + 1000*si + 10000*ni.
  - Range ≈ [30372009, 30416058]. Fully disjoint from prior range.
- r = 1..50, si = 1..5 (SNR index), ni = 1..4 (noise index).
- rng(seed, 'twister') called at the start of make_case for each signal.

## 5. Metrics

### Primary (per signal)
- output SNR (dB) = 10*log10( ||B_ref{clean}||^2 / ||B_ref{clean} - B_ref{recon}||^2 ), band [3500,5500] Hz.
- RRMSE, Pearson correlation (same band).
- THNR (dB) for each selected subset.
- selected mode mask (1..15 integer code), mode count.
- alpha0, selected bandwidth.
- runtime per signal (within worker).

### Primary comparison
- ΔSNR = outputSNR(E) - outputSNR(C), paired per signal (same noise seed).

### Secondary (per signal, no mass significance testing)
- selection regret = oracleSNR - eSNR.
- E == oracle, E in top-3 output-SNR subsets.
- Spearman correlation between THNR and output SNR across 15 subsets.
- oracle-is-all-modes (code 15) indicator.
- E subset size distribution (1,2,3,4 modes).
- B vs C output SNR difference.

## 6. Statistical analysis (frozen)

1. **20 cells** reported separately (4 noise × 5 SNR).
2. For each cell:
   - paired median difference ΔSNR.
   - paired mean difference ΔSNR (auxiliary).
   - 95% percentile-bootstrap CI on the paired median difference, **10000 resamples**, fixed bootstrap seed = 42.
   - Wilcoxon signed-rank test (two-sided) on paired differences.
   - Holm correction applied **across all 20 E-vs-C tests** (family of 20), not per-noise.
   - win rate = fraction of signals with E > C.
   - fraction |Δ| < 0.1 dB (practical equivalence).
   - fraction Δ > 0.1 dB (small effect).
   - fraction Δ > 0.5 dB (clear effect).
   - fraction Δ < -0.1 dB, Δ < -0.5 dB.
   - rank-biserial effect size.
3. **0.1 dB and 0.5 dB are descriptive engineering thresholds**, not statistical significance thresholds.
4. Bootstrap resamples the **paired differences**, not E and C separately.
5. Exploration set (original S1, seeds 20260929) and confirmation set (seeds 30261008) are **reported separately**. They are NOT pooled into n=100 per cell.
6. Consistency metrics (exploration vs confirmation):
   - fraction of 20 cells with same sign of median Δ.
   - Spearman correlation of the 20-cell median Δ vectors.
   - whether the three positive cells (white -15, white -10, pink -15) reproduce.
   - whether all 5 harmonic-noise cells remain non-positive.

## 7. Pre-registered confirmation criteria

### Supports the noise-dependence conclusion if ALL hold:
- White -15 dB, white -10 dB, pink -15 dB: median Δ > 0.
- At least 2 of those 3 cells: 95% CI does not cross 0.
- All 5 harmonic-noise cells: median Δ ≤ 0 (or at least 4 negative).
- Sign agreement between exploration and confirmation ≥ 16/20 cells.
- Spearman correlation of 20-cell median Δ ≥ 0.7.

### Does NOT support a stable E contribution if ANY holds:
- ≥ 2 of the 3 positive cells fail to reproduce (median ≤ 0).
- Sign agreement < 12/20.
- Spearman correlation < 0.4.
- E frequently far from oracle (median regret > 1.5 dB) while oracle consistently beats C.

If the "does not support" criteria trigger, the conclusion is downgraded further. **The seed is not re-rolled to obtain favourable results.**

## 8. Numerical equivalence check (run before confirmation)

- 20 signals drawn from the confirmation seed range.
- Run production `method_proposed` (variant E) and the diagnostic shared-decomposition script on the same signal.
- Compare: selected mode mask, selected mode count, max THNR, reconstructed signal, output SNR, RRMSE, correlation.
- Acceptance: mask identical; |THNR diff| < 1e-10; relative reconstruction norm diff < 1e-9.
- Tie handling (tie_db threshold, preference for fewer modes, enumeration order) must match production exactly.

## 9. What this experiment cannot prove

- It does not establish real-data validity (CWRU / XJTU-SY / semi-physical remain separate).
- Oracle is not a deployable method.
- The confirmation set uses the same signal model as S1; it guards against seed-overfitting, not model misspecification.
- Results are conditional on K=4, alpha_scale=200, H=3, delta=3 Hz, 0–500 Hz envelope range.

## 10. Deliverables

- `confirmation_bcde_oracle.csv` — 1000 rows, per-signal.
- `confirmation_ec_full20.csv` — 20 rows, cell-level paired statistics.
- `confirmation_consistency.csv` — exploration vs confirmation comparison.
- Updated manuscript sections (EN + CN) reporting both sets separately.
- Updated supplementary material with full 20-cell confirmation table.
